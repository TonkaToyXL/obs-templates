# Holographic Voice-Reactive Orb

Free OBS browser overlay from [TonkaToyXL](https://github.com/TonkaToyXL/obs-templates). The orb glows and pulses when you talk.

## Install (easiest — double-click)

| Platform | What to double-click |
|----------|----------------------|
| **Mac** | `install.command` |
| **Windows** | `Install.bat` |

That copies files to `Documents/TonkaToyXL-OBS/holographic-orb/` and opens a step-by-step install guide in your browser.

Then in OBS: **Sources → + → Browser** → check **Local file** → pick `overlays/orb.html` from the installed folder.

## Install guide (slides)

Open `docs/install-guide.html` in any browser — arrow keys to step through.

## Requirements

- OBS Studio 30+
- WebSocket enabled: **OBS → Settings → WebSocket**

## Customize

Edit the `CONFIG` block at the top of `overlays/orb.html` (colors, mic name, WebSocket password).

Replace `assets/avatar.svg` with your own logo (1024×1024 PNG/SVG with transparency).

## Video walkthrough

_Coming soon — link will appear here after the live build stream._
